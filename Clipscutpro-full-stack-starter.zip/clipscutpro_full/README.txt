CLIPSCUTPRO — FULL-STACK STARTER
================================

WHAT'S INCLUDED
- frontend/index.html: Clipscutpro website, wired to the local API.
- backend/main.py: FastAPI upload/transcription/highlight/render API.
- Whisper via faster-whisper: speech-to-text, running locally on your computer.
- FFmpeg: cuts clips and formats them as vertical 9:16, square 1:1, or landscape 16:9.

IMPORTANT LIMITATIONS
This is a local development starter, not a deployed public service. The first run downloads the Whisper "base" model and may take time. The highlight finder is a simple transcript heuristic, not a trained viral-content predictor. It finds candidate speech windows; please review clips before publishing. Portrait output uses a centered crop, so a person near the edge may be cropped. No subtitles, face tracking, user accounts, or cloud storage are included yet.

STEP 1 — INSTALL PREREQUISITES
1. Install Python 3.10 or newer.
2. Install FFmpeg and make sure both `ffmpeg` and `ffprobe` work from a terminal.
   - Windows: install an FFmpeg build and add its bin folder to PATH.
   - macOS: `brew install ffmpeg` (if Homebrew is already installed).
   - Linux: install ffmpeg using your distribution's package manager.
3. Extract this ZIP to a folder you can find.

STEP 2 — START THE BACKEND
Open a terminal in the extracted `backend` folder.

Windows:
  py -m venv .venv
  .venv\Scripts\activate
  pip install -r requirements.txt
  uvicorn main:app --reload

macOS / Linux:
  python3 -m venv .venv
  source .venv/bin/activate
  pip install -r requirements.txt
  uvicorn main:app --reload

Wait until the terminal says the server is running at http://127.0.0.1:8000.
Test the health endpoint by opening http://127.0.0.1:8000/api/health

STEP 3 — OPEN THE WEBSITE
Keep the backend terminal running.
Open frontend/index.html in a modern browser. If your browser blocks local file requests,
serve the frontend from another terminal:
  python -m http.server 5500 --directory frontend
Then open http://127.0.0.1:5500

STEP 4 — CREATE CLIPS
1. Select a video with spoken audio (MP4/MOV/WEBM/MKV, max 500 MB).
2. Pick clip length and output aspect ratio.
3. Click Generate clips.
4. Download the generated MP4 files.

TROUBLESHOOTING
- "FFmpeg/ffprobe was not found": install FFmpeg and restart the terminal.
- Whisper installation fails: check Python version and install the current supported Python version.
- First request is slow: the Whisper model is downloaded on first use.
- Browser cannot connect: make sure backend is running at 127.0.0.1:8000.
- Out of memory / slow: try a shorter, lower-resolution video or set WHISPER_MODEL=tiny before starting the backend.

SAFETY / PRIVACY BEFORE PUBLIC LAUNCH
- This local starter processes the video on your computer; it does not upload to a cloud AI provider.
- Do not expose this development server directly to the public internet.
- Before public deployment, add authentication, rate limits, secure object storage, job queues,
  file-size/duration limits, malware scanning, retention/deletion controls, and HTTPS.
- Keep any future API keys on the server, never in frontend JavaScript.
- Only upload videos you own or have permission to process.
